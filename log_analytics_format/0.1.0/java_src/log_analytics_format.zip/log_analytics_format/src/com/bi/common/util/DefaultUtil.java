package com.bi.common.util;


public final class DefaultUtil {

    public static final String TAB_SEPARATOR = "\t";

    public static final String COMMA_SEPARATOR = ",";
    
    public static final String MAC_CODE = "000000000000";
    public static final String FUDID = "000000000000";
    public static final String INFOHASH = "0000000000000000000000000000000000000000";
    public static final String SERIAL_ID = "-999";
    public static final String MEDIA_ID = "-999";
    public static final String CHANNELL_ID = "-999";
    public static final String MEDIA_NAME = "unknown";
    public static final String MEDIA_TYPE_ID = "-999";
    public static final String NET_TYPE = "-999";
    public static final String BUFFER_OK = "-999";
    public static final String BUFFER_POS = "-999";
    public static final String BUFFER_TIME = "-999";
    public static final String BUFFER_DRATE = "-999";
    public static final String BUFFER_NRATE = "-999";
    public static final String BUFFER_MS_OK = "-999";
    public static final String PLAYER_TYPE = "-999";
    public static final String CL = "-999";
    public static final String MESSAGE_ID = "-999";
    public static final String LIAN = "-999";
}