package com.bi.common.logenum;

public enum DMMediaTypeEnum {
	 PLAY_TYPE, MEDIA_TYPE, SUBJECT_TYPE, MEDIA_NAME, MEDIA_ID, SEARIA_ID, TAG_ID, RELATE_VIDEO_ID;
}
