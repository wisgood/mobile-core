package com.bi.common.logenum;

public enum BootEnum {
    TIMESTAMP, IP, MAC, VERSION, CHANNEL, OS, STARTTYPE, ERROR_CODE, HC, HARDWARE_ACCELERATION, YY, TRAY_LIMIT

}
