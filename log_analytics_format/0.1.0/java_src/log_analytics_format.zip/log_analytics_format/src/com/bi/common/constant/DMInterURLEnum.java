package com.bi.common.constant;

public enum DMInterURLEnum {
	THIRD_ID, THIRD_NAME, SECOND_ID, SECOND_NAME, FIRST_ID,FIRST_NAME, URL, NAME_ID, NAME;

}
