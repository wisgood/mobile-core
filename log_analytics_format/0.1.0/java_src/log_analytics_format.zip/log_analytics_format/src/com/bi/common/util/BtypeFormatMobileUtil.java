package com.bi.common.util;

public class BtypeFormatMobileUtil {

	
	
}
