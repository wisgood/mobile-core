package com.bi.common.dm.pojo;

/**
 * #infohash, 分集ID，媒体ID，频道ID
 * 
 * @author fuys
 * 
 */
public enum DMInforHashEnum {
    IH, SERIAL_ID, MEIDA_ID, CHANNEL_ID, MEIDA_NAME;
}
