package com.bi.common.logenum;

public enum FormatFbufferEnum {

    DATE_ID, HOUR_ID, PLAT_ID, VERSION_ID, MAC, IP, MID,TIMESTAMP;

}