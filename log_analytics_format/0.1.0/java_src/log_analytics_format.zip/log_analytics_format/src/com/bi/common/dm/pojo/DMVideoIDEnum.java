package com.bi.common.dm.pojo;
/**
 * #短视频ID, 频道ID, 视频名称
 * @author liuyn
 *
 */
public enum DMVideoIDEnum {
	VIDEOID, CHANNEL_ID, VIDEONAME

}
