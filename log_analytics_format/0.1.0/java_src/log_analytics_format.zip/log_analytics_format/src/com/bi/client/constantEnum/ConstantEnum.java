package com.bi.client.constantEnum;

public enum ConstantEnum {
	PROVINCE_ID,CITY_ID,ISP_ID;
}
