package com.bi.test;

public class GenericPV {

}
